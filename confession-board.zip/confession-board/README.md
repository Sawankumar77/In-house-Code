# Anonymous Confessions Board

## Setup

### Backend (PHP + MySQL)
1. Import `backend/db.sql` into your MySQL server.
2. Update `backend/config.php` with your DB credentials.
3. Host the backend folder on your PHP server (e.g., XAMPP, WAMP, or LAMP).

### Frontend (React)
1. Navigate to the `frontend` folder.
2. Run `npm install` to install dependencies.
3. Run `npm start` to start the React app.

### Usage
- Open the React app in your browser.
- The frontend communicates with the backend PHP API (update fetch URLs if needed).
