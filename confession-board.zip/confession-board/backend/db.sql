CREATE DATABASE IF NOT EXISTS confession_board;
USE confession_board;

CREATE TABLE confessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(50),
    content TEXT,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    comments INT DEFAULT 0,
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    confession_id INT,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (confession_id) REFERENCES confessions(id)
);