<?php
include 'config.php';

$data = json_decode(file_get_contents("php://input"), true);
$category = $conn->real_escape_string($data['category']);
$content = $conn->real_escape_string($data['content']);

$sql = "INSERT INTO confessions (category, content) VALUES ('$category', '$content')";
if ($conn->query($sql) === TRUE) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => $conn->error]);
}
?>