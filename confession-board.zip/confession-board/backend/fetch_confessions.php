<?php
include 'config.php';

$sql = "SELECT * FROM confessions ORDER BY created_at DESC";
$result = $conn->query($sql);

$confessions = [];
while($row = $result->fetch_assoc()) {
    $confessions[] = $row;
}
echo json_encode($confessions);
?>