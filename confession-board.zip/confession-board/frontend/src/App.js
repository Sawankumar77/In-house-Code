import React, { useState, useEffect } from "react";
import ConfessionCard from "./ConfessionCard";
import ConfessionModal from "./ConfessionModal";

export default function App() {
  const [confessions, setConfessions] = useState([]);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetch("http://localhost/confession-board/backend/fetch_confessions.php")
      .then(res => res.json())
      .then(data => setConfessions(data));
  }, []);

  const addConfession = confession => {
    setConfessions([confession, ...confessions]);
  };

  return (
    <div className="app-bg">
      <header className="header">
        <div className="logo-spin">
          <span role="img" aria-label="logo" style={{fontSize: '2.2em'}}>💜</span>
        </div>
        <div>
          <h1>Anonymous Confessions</h1>
          <p>Share your story, heal your soul</p>
        </div>
        <button className="share-btn" onClick={() => setShowModal(true)}>
          + Share Confession
        </button>
      </header>
      <main>
        <section className="hero">
          <h2>Your Safe Space</h2>
          <p>
            Share your deepest thoughts, wildest dreams, and untold stories without judgment.<br/>
            This is where honesty lives and healing begins.
          </p>
          <div className="features">
            <div className="feature-card">
              <span role="img" aria-label="shield">🛡️</span>
              <h3>100% Anonymous</h3>
              <p>No accounts, no tracking, just pure expression.</p>
            </div>
            <div className="feature-card">
              <span role="img" aria-label="community">👥</span>
              <h3>Safe Community</h3>
              <p>Connect through shared experiences and empathy.</p>
            </div>
            <div className="feature-card">
              <span role="img" aria-label="relief">⚡</span>
              <h3>Instant Relief</h3>
              <p>Feel the weight lift as you share your truth.</p>
            </div>
          </div>
        </section>
        <section className="confessions-list">
          {confessions.map(conf => (
            <ConfessionCard key={conf.id} confession={conf} />
          ))}
        </section>
      </main>
      {showModal && (
        <ConfessionModal
          onClose={() => setShowModal(false)}
          onSubmit={addConfession}
        />
      )}
    </div>
  );
}