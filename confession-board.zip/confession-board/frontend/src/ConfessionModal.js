import React, { useState } from "react";

const categories = [
  { name: "Heartbreak", emoji: "💔" },
  { name: "Life Lesson", emoji: "🧠" },
  { name: "Funny", emoji: "😂" },
  { name: "Deep Thoughts", emoji: "🤔" },
  { name: "Random", emoji: "🎲" }
];

export default function ConfessionModal({ onClose, onSubmit }) {
  const [category, setCategory] = useState("Random");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!content.trim()) return;
    setLoading(true);
    const res = await fetch("http://localhost/confession-board/backend/submit_confession.php", {
      method: "POST",
      body: JSON.stringify({ category, content }),
      headers: { "Content-Type": "application/json" }
    });
    const data = await res.json();
    if (data.success) {
      onSubmit({ category, content, likes: 0, dislikes: 0, comments: 0, views: 0, created_at: new Date().toISOString() });
      onClose();
    }
    setLoading(false);
  };

  return (
    <div className="modal-bg">
      <div className="modal">
        <button className="close-btn" onClick={onClose}>×</button>
        <h2>Share Your Story</h2>
        <div className="category-select">
          {categories.map(cat => (
            <button
              key={cat.name}
              className={category === cat.name ? "active" : ""}
              onClick={() => setCategory(cat.name)}
            >
              {cat.emoji} {cat.name}
            </button>
          ))}
        </div>
        <textarea
          maxLength={1000}
          placeholder="What's on your mind? Share your story, your feelings, your truth... This is your safe space."
          value={content}
          onChange={e => setContent(e.target.value)}
        />
        <div>{content.length}/1000 characters</div>
        <button className="share-anon-btn" onClick={handleSubmit} disabled={loading}>
          {loading ? "Sharing..." : "Share Anonymously"}
        </button>
        <div className="modal-note">Your identity is completely anonymous</div>
      </div>
    </div>
  );
}