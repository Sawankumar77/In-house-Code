import React, { useState } from "react";

const categoryColors = {
  "Deep Thoughts": "#a259ec",
  "Life Lesson": "#2ec4b6",
  "Funny": "#ffbe0b",
  "Heartbreak": "#ff006e",
  "Random": "#00b4d8"
};

const categoryEmojis = {
  "Deep Thoughts": "🤔",
  "Life Lesson": "🧠",
  "Funny": "😂",
  "Heartbreak": "💔",
  "Random": "🎲"
};

export default function ConfessionCard({ confession }) {
  const [likes, setLikes] = useState(confession.likes);
  const [dislikes, setDislikes] = useState(confession.dislikes);
  const [comments] = useState(confession.comments);

  const handleLike = type => {
    fetch("http://localhost/confession-board/backend/like_confession.php", {
      method: "POST",
      body: JSON.stringify({ id: confession.id, type }),
      headers: { "Content-Type": "application/json" }
    });
    if (type === "like") setLikes(likes + 1);
    else setDislikes(dislikes + 1);
  };

  return (
    <div className="confession-card" style={{borderColor: categoryColors[confession.category]}}>
      <div className="confession-header">
        <span className="category" style={{background: categoryColors[confession.category]}}>
          {categoryEmojis[confession.category] || "📝"} {confession.category}
        </span>
        <span className="timestamp">{timeAgo(confession.created_at)}</span>
      </div>
      <div className="confession-content">{confession.content}</div>
      <div className="confession-actions">
        <button onClick={() => handleLike("like")} className="like-btn">
          👍 {likes}
        </button>
        <button onClick={() => handleLike("dislike")} className="dislike-btn">
          👎 {dislikes}
        </button>
        <button className="comment-btn" disabled>
          💬 {comments}
        </button>
        <span className="views">👁️ {confession.views} views</span>
      </div>
    </div>
  );
}

function timeAgo(dateStr) {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = Math.floor((now - date) / 1000);
  if (diff < 60) return `${diff} seconds ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)} minutes ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} hours ago`;
  return `${Math.floor(diff / 86400)} days ago`;
}